
#LIBRARIES (packages) USED 

library(shiny)
    #shinyapp

library(tidyverse)
    #For cleaning and filtering 

library(readxl)
    #For loading/reading in the excel files

library(janitor)
    #This is where the function clean_names() comes from. 
    #It cleans all column names in a df, default is snake_case.

library(shinyWidgets)
    #Where I got the fancy pickerInput() function & 'Select All/ Deselect All' feature

library(DT)
    #renderDataTable() function - allows the search bar and ordering alphabetically of columns (lets you do javascript tings in R)




#-------------------------------------------------------------------------------------------------#

#TABLE OF CONTENTS

    #Load Data File
    #Cleaning
    #Creating Toggle Options

    #User Interface Code
        #Page Title
        #Intro Text
        #Toggles - filter drop downs & go button
        #Table (telling the webpage where to put the table)
        #Bottom Text - disclosure

    #Server Code
        #Filter Organization Type
        #Filter Priority Area
        #Filter County
        #Table - this is where you can customize the output table

    #Run the App




#-------------------------------------------------------------------------------------------------#
    
#LOAD DATA FILE 
    
cco_data <- read_xlsx("data/cco_data.xlsm", sheet = 1, na ="NA")

#In this section the macro enabled excel file (.xlsm) data file is being "read" into R and saved (<-) as an object called cco_data
#The function read_xlsx() can take all types of excel files. The file extension will be different (.xls, .xlsx, .xlsm) 
#If you wish to load in a csv file (.csv) you must use read_csv(), change the file extension in quotes to '.csv', and delete the arguement 'sheet = 1'




#-------------------------------------------------------------------------------------------------#
 
#CLEANING
    
cco_data <- cco_data %>% 
    clean_names() %>% 
    select(
        county:focus_area
        ) %>% 
    rename(
        "Organization Type" = "type_of_organization",
        "Priority Area" = "priority_area",
        "Organization Name" = "name",
        "Focus Area" = "focus_area",
        "County" = "county"
    )

#In this section of the code the cco_data object is being re-written as the same data but cleaned up a bit

#clean_names() is going through and making all the column names snake_case so like this: priority_area (all lower case with '_' for spaces)
    #This was done so that no matter the format of the column names, they will be made uniform for the code's sake.

#select() then selects the columns from 'county' to 'focus_area'

#rename() is renaming these columns to something that will look better for the user in the final table that the app creates




#-------------------------------------------------------------------------------------------------#
    
#CREATING TOGGLE OPTIONS

priorities <- unique(cco_data$'Priority Area')
    priorities <- priorities[-9] #the [-9] is taking off a priority that was really long and didn't make sense
                                 #It said something like "this CHNA was done by NEON....." and then really long
                                 #IN THE FUTURE DELETE [-9] if this is no longer an issue
    
counties <- unique(cco_data$County) 

counties <- counties[-1] #the [-1] is taking off "Statewide" from the list, since this was a confusing toggle option for 'county'
organizations <- unique(cco_data$'Organization Type') 

#Here, the function unique() is being used to get a list of every unique value found in each column
#Each list is then being saved as an object that reflects the name of each column
#These objects/lists will be used as the choices argument in the pickerInput() functions that are under the label '#TOGGLES' and start on line 105

#IN THE FUTURE DELETE [-9] from line 62, this was done to get rid of a lengthy value in the column that wouldn't have been used as a filter anyways


 

#-------------------------------------------------------------------------------------------------#
    
#USER INTERFACE CODE (UI)

#This part of the code creates the webpage/app that people will interact with
#This is the place to edit text or page organization

ui<- fluidPage(
    
    #PAGE TITLE
    titlePanel(strong("Oregon Health Improvement Plan Data")),
    
    #INTRO TEXT
    fluidRow(
        column(12,
               h4("This app filters community health improvement plan (CHIP) data that was assembled by going through CHIPs from all over Oregon. However, the priority areas shown are not exhaustive.", 
                  style = "font-family: Helvetica; font-si20pt"),
               h4("Make filter selections below, according to your interests. Multiple items can be selected in each drop down menu, or none at all.", 
                  style = "font-family: Helvetica; font-si20pt"),
               h4("Press", span(em("'Go' "), style = "color:LimeGreen"), "when you are ready to see a list of all the entries that match your selections. If you change your selections, you must press go again. ", 
                  style = "font-family: Helvetica; font-si20pt"),
               br()
               )
        ),
    
    
    #TOGGLES - filter drop downs & go button
    sidebarLayout(
        
        sidebarPanel(
               pickerInput(
                   inputId = "type",
                   label = "Organization Type(s)",
                   choices = organizations,
                   options = list(`actions-box` = TRUE),
                   multiple = TRUE
                   ),
               
               pickerInput(
                   inputId = "county",
                   label = "Choose a county",
                   choices = counties,
                   options = list(`actions-box` = TRUE),
                   multiple = TRUE
                   ),
               
               pickerInput(
                   inputId = "priority",
                   label = "Select priority area(s) of interest:",
                   choices = priorities,
                   options = list(`actions-box` = TRUE),
                   multiple = TRUE
                   ),
               
               actionButton(
                   inputId = "go", 
                   label = "Go"
                   )
               ),
        
        #TABLE
        mainPanel(
            dataTableOutput("mytable")
            )
        ),
    
    #BOTTOM TEXT - disclosure
    fluidRow(
            column(12,
                   h5(em("This is a shinyapp created by Emory Neer in the spring of 2021. Data was compiled and synthesized by Joanna Yan from the most recent publicly available community health improvement plans in Oregon. Project was overseen by Rose Locklear and Anona Gund. Please contact <emoryneer@gmail.com> for app issues and <jyan.joanna@gmail.com> for methodology & data questions.
"), 
                      style = "font-family: Helvetica; color:DarkGray"),
                   br()
                   )
            )
    )


#-------------------------------------------------------------------------------------------------#

#SERVER CODE

#This part of the code does the filtering
#Each if/else statement uses a set of conditions to filter the data save that filter as a new object which is then used as the data for the next filter
#Doing it this way allowed me to have blank inputs work. This was my solution but there may be better ones!

server <- function(input, output) {
    
    
    mydata <- eventReactive(input$go, {
        
        
        #FILTER ORGANIZATION TYPE
        
        if (is.null(input$type)){ 
            #The first condition is always checking if the input from the user interface was blank
            
            filtered <- cco_data 
            #If blank the filter object remains the cco_data object
            
        } else {
            if (!is.null(input$type)){ 
                #If the condition is not blank...
                filtered <- cco_data %>% filter(`Organization Type` %in% input$type)
                #The filter object is cco_data filtered by every entry where the value in the column 'Organization Type' matches the input for 'type' from the UI
            }
        }
        
        
        
        
        #FILTER PRIORITY AREAS
            #This section works the same as above. 
            #If input is blank the filter object remains the previous filter object. 
            #If not the new filter object is the old filter object, but filtered with the UI input
        
        if (is.null(input$priority)){
            filtered2 <- filtered
        } else {
            if (!is.null(input$priority)){
                filtered2 <- filtered %>% filter(`Priority Area` %in% input$priority)
            }
        }
       
        
         
        
        #FILTER COUNTY
            #This section works slightly different because if 'OHA' was selected in the >organization type toggle<, and then a county was also selected, for example 'Benton', nothing would get returned in the table
            #This is because all entries that have 'OHA' as their organization, have Statewide as their county value.
        
        if (is.null(input$county)){ #If county input is blank...
            filtered3 <- filtered2 #Make no changes when creating the final data object
            
            } else if (!is.null(input$county) & ("OHA" %in% input$type)){ #If county input is not blank and 'OHA' is in the organization type input from the UI....
                filtered3 <- filtered2 %>% filter(County %in% c(isolate(input$county), "Statewide")) #Filter for all entries that the value in the column 'County' is the UI county input or is 'Statewide'
                
                } else if (!is.null(input$county) & !("OHA" %in% input$type)){ #If the county is not blank & the organization type doesn't include 'OHA'
                    filtered3 <- filtered2 %>% filter(County %in% input$county) #Then the filter object is just filtered by the county input 
                }
        })

                
    
    #TABLE - this is where you can customize the output table 
    output$mytable <- renderDataTable(mydata(),
                                      options = list(
                                          pageLength = 100, #Shows 100 entries per page unless specified otherwise
                                          lengthMenu = c(50, 100, 200), #Options for how many entries you can show per page
                                          order = list(list(4, 'asc')) #This is how the table defaults to grouping entries by 'Priority Area'
                                                                       #This setting sets the default ordering of the table to column 4 (priority area) being in ascending alphabetical order
                                          )
                                      )
    
}



#-------------------------------------------------------------------------------------------------#


#RUN THE APP
shinyApp(ui = ui, server = server)

#This is the function where the app actually runs it's only arguments are the ui and server code objects from above






